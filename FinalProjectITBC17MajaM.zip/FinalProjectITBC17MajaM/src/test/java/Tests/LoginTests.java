package Tests;

import Base.BaseTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {
    @BeforeMethod
    public void pageSetUp() {
        driver.navigate().to("https://www.saucedemo.com/");
    }

    @Test (priority = 10)
    public void assertLogoText() {
        homePage.assertLogo();
    }

    @Test (priority = 15)
    public void assertCredentials() {
        homePage.assertLoginCredentials();
        homePage.assertPasswordCredential();
    }

    @Test (priority = 17)
    public void userCanLogInAndLogOutExcel() throws InterruptedException {
        for (int i = 1; i < excelReader.getLastRow("Login"); i++) {
            String validUsername = excelReader.getStringData("Login", i, 0);
            String validPassword = excelReader.getStringData("Login", 1, 1);
            homePage.usernameInputField(validUsername);
            Thread.sleep(1000);
            homePage.passwordInputField(validPassword);
            Thread.sleep(1000);
            homePage.clickOnTheLoginButton();
            sidebarPage.clickOnBurgerMenuButton();
            sidebarPage.logout();
        }
    }

    @Test(priority = 20)
    public void verifyUserCanLogInAndLogout() {
        homePage.usernameInputField("standard_user");
        homePage.passwordInputField("secret_sauce");
        homePage.clickOnTheLoginButton();
        sidebarPage.clickOnBurgerMenuButton();
        sidebarPage.logout();

    }

    @Test (priority = 25)
    public void userCannotLoginWithInvalidDataExcel() throws InterruptedException {
        for (int i = 1; i < excelReader.getLastRow("Login"); i++) {
            String invalidUsername = excelReader.getStringData("Login", i, 2);
            String invalidPassword = excelReader.getStringData("Login", i, 3);
            homePage.usernameInputField(invalidUsername);
            Thread.sleep(1000);
            homePage.passwordInputField(invalidPassword);
            Thread.sleep(1000);
            homePage.clickOnTheLoginButton();
            homePage.errorMessageAssert();
            Thread.sleep(1000);
        }
    }

    @Test(priority = 30)
    public void verifyUserCannotLoginWithInvalidData() {
        homePage.usernameInputField("");
        homePage.passwordInputField("");
        homePage.clickOnTheLoginButton();
        homePage.errorMessageAssert();

    }
}
