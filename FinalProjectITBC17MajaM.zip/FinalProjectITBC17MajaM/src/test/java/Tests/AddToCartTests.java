package Tests;

import Base.BaseTest;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.lang.reflect.Array;

public class AddToCartTests extends BaseTest {
    @BeforeMethod
    public void pageSetUp() {

        driver.navigate().to("https://www.saucedemo.com/");
        homePage.usernameInputField("standard_user");
        homePage.passwordInputField("secret_sauce");
        homePage.clickOnTheLoginButton();
    }

    @Test(priority = 10)
    public void addToCartAndRemoveFromCart() {
        inventoryProductsPage.emptyShoppingCartLogo();
        inventoryProductsPage.addBackpackProductToCart();
        inventoryProductsPage.removeBackpack();

    }

    @Test(priority = 15)
    public void clikOnSideBarLinksAndCloseBurgerMenu() {
        sidebarPage.clickOnBurgerMenuButton();
        sidebarPage.clickOnAboutSideBarLink();
        driver.navigate().back();
        sidebarPage.clickOnBurgerMenuButton();
        sidebarPage.clickAllItemsSideBarLink();  // pada test --> nisu klikabilni linkovi/ne pokrece se nista posle klika
        driver.navigate().back();
        sidebarPage.clickOnBurgerMenuButton();
        sidebarPage.clickOnResetAppLink(); // pada test --> nisu klikabilni linkovi/ne pokrece se nista posle klika
        driver.navigate().back();
        sidebarPage.clickOnBurgerMenuButton();
        sidebarPage.closeBurgerMenu();
    }

    @Test(priority = 20)
    public void addAndRemoveAllItemsToCartOnInventoryPage() {
        inventoryProductsPage.addBackpackProductToCart();
        inventoryProductsPage.addBikeLightToCart();
        inventoryProductsPage.addBoltTShirtToCart();
        inventoryProductsPage.addOnsieToCart();
        inventoryProductsPage.addRedTShirtToCart();
        inventoryProductsPage.addFleeceJacketToCart();
        inventoryProductsPage.removeBackpack();
        inventoryProductsPage.removeBikeLight();
        inventoryProductsPage.removeBoltShirt();
        inventoryProductsPage.removeFleeceJacket();
        Actions actions = new Actions(driver);
        actions.scrollByAmount(0, 300);
        actions.perform();
        inventoryProductsPage.removeOnsie();
        inventoryProductsPage.removeRedTShirt();
    }

    @Test(priority = 30)
    public void continueShoppingAndRemoveProductsFromCartOnCartPage() {
        inventoryProductsPage.emptyShoppingCartLogo();
        inventoryProductsPage.addBoltTShirtToCart();
        inventoryProductsPage.shoppingCartBadgeNumber();
        inventoryProductsPage.clickOnCartIcon();
        cartPage.assertLogoSwagLabs();
        //inventoryProductsPage.clickOnCartIcon();
        //cartPage.
//todo

    }

    @Test(priority = 70)
    public void assertLogoAndTitle() {
        inventoryProductsPage.assertSwagLabsLogo();
        inventoryProductsPage.assertProductTitle();
    }

    @Test(priority = 80)
    public void openTwitterInventoryPage() {
        inventoryProductsPage.clickOnTwitterButton();
    }

    //@Test (priority = )


}
