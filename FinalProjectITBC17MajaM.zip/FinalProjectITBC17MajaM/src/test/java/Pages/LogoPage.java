package Pages;

import Base.BaseTest;

public class LogoPage extends BaseTest {
}
