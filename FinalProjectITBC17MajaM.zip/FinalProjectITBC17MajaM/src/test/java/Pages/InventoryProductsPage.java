package Pages;

import Base.BaseTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class InventoryProductsPage extends BaseTest {

    public InventoryProductsPage() {
        PageFactory.initElements(driver, this);
    }


    @FindBy(className = "app_logo")
    public WebElement appLogo;

    @FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
    public WebElement productsTitle;


    @FindBy(id = "shopping_cart_container")
    WebElement cartIcon;

    @FindBy(className = "shopping_cart_badge")
    WebElement shoppingCartBadge;

    @FindBy(id = "add-to-cart-sauce-labs-backpack")
    WebElement addBackpackToCartButton;

    @FindBy(id = "add-to-cart-sauce-labs-bike-light")
    WebElement addBikeLightToCartButton;

    @FindBy(id = "add-to-cart-sauce-labs-bolt-t-shirt")
    WebElement addBoltTShirtToCartButton;

    @FindBy(id = "add-to-cart-sauce-labs-fleece-jacket")
    WebElement addFleeceJacketToCartButton;

    @FindBy(id = "add-to-cart-sauce-labs-onesie")
    WebElement addOnsieToCartButton;

    @FindBy(id = "add-to-cart-test.allthethings()-t-shirt-(red)")
    WebElement addRedTShirtToCartButton;

    @FindBy(id = "remove-sauce-labs-backpack")
    WebElement removeBackpackButton;

    @FindBy(id = "remove-sauce-labs-bike-light")
    WebElement removeBikeLightsButton;

    @FindBy(id = "remove-sauce-labs-bolt-t-shirt")
    WebElement removeBoltTShirtButton;

    @FindBy(id = "remove-sauce-labs-fleece-jacket")
    WebElement removeFleeceJacketButton;

    @FindBy(id = "remove-sauce-labs-onesie")
    WebElement removeOnsieButton;

    @FindBy(id = "remove-test.allthethings()-t-shirt-(red)")
    WebElement removeRedTShirtButton;

    @FindBy(className = "footer_copy")
    WebElement footerCopy;

    @FindBy(className = "social_twitter")
    WebElement twitterButton;

    @FindBy(className = "social_facebook")
    WebElement facebookButton;

    @FindBy(className = "social_linkedin")
    WebElement linkedInButton;

 /*   String actualFooterCopy = "";
    String expectefFooterCopy = "";

    public String getActualFooterCopy() {
        return actualFooterCopy;
    }

    public String getExpectefFooterCopy() {
        return expectefFooterCopy;
    }
    */

    //------------

    public void assertSwagLabsLogo() {
        Assert.assertTrue(appLogo.isDisplayed());
    }

    public void assertProductTitle() {
        Assert.assertTrue(productsTitle.isDisplayed());
    }

    public void clickOnCartIcon() {
        Assert.assertTrue(cartIcon.isDisplayed());
        cartIcon.click();
    }

    public void emptyShoppingCartLogo() {
        Assert.assertTrue(cartIcon.isDisplayed());
    }

    public void shoppingCartBadgeNumber() {
        Assert.assertTrue(shoppingCartBadge.isDisplayed());
    }

    public void addBackpackProductToCart() {
        Assert.assertTrue(addBackpackToCartButton.isDisplayed());
        addBackpackToCartButton.click();
    }

    public void addBikeLightToCart() {
        Assert.assertTrue(addBikeLightToCartButton.isDisplayed());
        addBikeLightToCartButton.click();
    }

    public void addBoltTShirtToCart() {
        Assert.assertTrue(addBoltTShirtToCartButton.isDisplayed());
        addBoltTShirtToCartButton.click();
    }

    public void addFleeceJacketToCart() {
        Assert.assertTrue(addFleeceJacketToCartButton.isDisplayed());
        addFleeceJacketToCartButton.click();
    }

    public void addOnsieToCart() {
        Assert.assertTrue(addOnsieToCartButton.isDisplayed());
        addOnsieToCartButton.click();
    }

    public void addRedTShirtToCart() {
        Assert.assertTrue(addRedTShirtToCartButton.isDisplayed());
        addRedTShirtToCartButton.click();
    }

    public void removeBackpack() {
        Assert.assertTrue(removeBackpackButton.isDisplayed());
        removeBackpackButton.click();
    }


    public void removeBikeLight() {
        Assert.assertTrue(removeBikeLightsButton.isDisplayed());
        removeBikeLightsButton.click();
    }

    public void removeBoltShirt() {
        Assert.assertTrue(removeBoltTShirtButton.isDisplayed());
        removeBoltTShirtButton.click();
    }

    public void removeFleeceJacket() {
        Assert.assertTrue(removeFleeceJacketButton.isDisplayed());
        removeFleeceJacketButton.click();
    }

    public void removeOnsie() {
        Assert.assertTrue(removeOnsieButton.isDisplayed());
        removeOnsieButton.click();
    }

    public void removeRedTShirt() {
        Assert.assertTrue(removeRedTShirtButton.isDisplayed());
        removeRedTShirtButton.click();
    }

    public void clickOnTwitterButton() {
        Assert.assertTrue(twitterButton.isDisplayed());
        twitterButton.click();
    }

    public void clickOnFacebookButtonInventoryPg() {
        Assert.assertTrue(facebookButton.isDisplayed());
        facebookButton.click();
    }

    public void clickOnLinkedInButtonInventoryPg() {
        Assert.assertTrue(linkedInButton.isDisplayed());
        linkedInButton.click();
    }

    public void assertFooterTextInventoryPg() {
        Assert.assertTrue(footerCopy.isDisplayed());
    }

}
//todo prepisi sve metode i elemente koji se ponavljaju na ostalim Page klasama - futer, heder, sidebar, kasa