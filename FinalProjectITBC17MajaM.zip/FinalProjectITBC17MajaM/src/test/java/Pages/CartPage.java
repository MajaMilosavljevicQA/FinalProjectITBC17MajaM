package Pages;

import Base.BaseTest;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class CartPage extends BaseTest {

    public CartPage() {
        PageFactory.initElements(driver, this);
    }

    @FindBy(className = "app_logo")
    WebElement logoSwagLabs;

    @FindBy(linkText = "Your Cart")
    WebElement yourCartHeader;

    @FindBy(id = "shopping_cart_container")
    WebElement cartIcon;

    @FindBy(css = ".fa-layers-counter.shopping_cart_badge")
    WebElement shoppingCartBadge;

    @FindBy(className = "inventory_item_name")
    WebElement inventoryItemName;

    @FindBy(id = "continue-shopping")
    WebElement continueShoppingButton;

    @FindBy(id = "checkout")
    WebElement checkoutButton;

    @FindBy(className = "cart_quantity")
    WebElement cartQuantity;

    @FindBy(className = "footer_copy")
    WebElement footerCopy;

    @FindBy(className = "social_twitter")
    WebElement twitterButton;

    @FindBy(className = "social_facebook")
    WebElement facebookButton;

    @FindBy(className = "social_linkedin")
    WebElement linkedInButton;

    @FindBy(id = "remove-sauce-labs-backpack")
    WebElement removeBackpackButton;

    @FindBy(id = "remove-sauce-labs-bike-light")
    WebElement removeBikeLightsButton;

    @FindBy(id = "remove-sauce-labs-bolt-t-shirt")
    WebElement removeBoltTShirtButton;

    @FindBy(id = "remove-sauce-labs-fleece-jacket")
    WebElement removeFleeceJacketButton;

    @FindBy(id = "remove-sauce-labs-onesie")
    WebElement removeOnsieButton;

    @FindBy(id = "remove-test.allthethings()-t-shirt-(red)")
    WebElement removeRedTShirtButton;


    public void assertLogoSwagLabs() {
        Assert.assertTrue(logoSwagLabs.isDisplayed());
    }

    public void assertTitleYourCart() {
        Assert.assertTrue(yourCartHeader.isDisplayed());
    }

    public void clickOnContinueShoppingButton() {
     //   Assert.assertTrue(continueShoppingButton.isDisplayed());
        continueShoppingButton.click();
    }
    public void removeBackpackCartPg() {
        Assert.assertTrue(removeBackpackButton.isDisplayed());
        removeBackpackButton.click();
    }


    public void removeBikeLightCartPg() {
        Assert.assertTrue(removeBikeLightsButton.isDisplayed());
        removeBikeLightsButton.click();
    }

    public void removeBoltShirtCartPg() {
        Assert.assertTrue(removeBoltTShirtButton.isDisplayed());
        removeBoltTShirtButton.click();
    }

    public void removeFleeceJacketCartPg() {
        Assert.assertTrue(removeFleeceJacketButton.isDisplayed());
        removeFleeceJacketButton.click();
    }

    public void removeOnsieCartPg() {
        Assert.assertTrue(removeOnsieButton.isDisplayed());
        removeOnsieButton.click();
    }

    public void removeRedTShirtCartPg() {
        Assert.assertTrue(removeRedTShirtButton.isDisplayed());
        removeRedTShirtButton.click();
    }

    public void clickOnTwitterButtonCartPage() {
        Assert.assertTrue(twitterButton.isDisplayed());
        twitterButton.click();
    }

    public void clickOnFacebookButtonCartPage() {
        Assert.assertTrue(facebookButton.isDisplayed());
        facebookButton.click();
    }

    public void clickOnLinkedInButtonCartPage() {
        Assert.assertTrue(linkedInButton.isDisplayed());
        linkedInButton.click();
    }

    public void assertFooterText() {
        Assert.assertTrue(footerCopy.isDisplayed());
    }

}
